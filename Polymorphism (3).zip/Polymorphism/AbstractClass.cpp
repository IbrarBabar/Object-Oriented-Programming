#include <iostream>
using namespace std;
class Base_abstract          
{
    public:
    virtual void print() = 0;    // Pure Virtual Function
};
class Derived_class:public Base_abstract
{
    public:
    void print()
    { 
        cout << "Overriding pure virtual function in derived class\n"; 
	} 
}; 
int main() { 
		// Base obj; 
		//Compile Time Error 
		Base_abstract *b; 
		Derived_class d; 
		b = &d; 
		b->print();
		//d.print();
}
