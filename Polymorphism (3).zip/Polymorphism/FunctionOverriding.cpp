#include<iostream>
using namespace std;
class Animal {
  public:
    void animalSound() {
    cout << "The animal makes a sound \n" ;
  }
  void print()
  {
  	cout<<"hi"<<endl;
  }
};

// Derived class
class Cat : public Animal {
  public:
    void animalSound() {
    cout << "The Cat says: meow \n" ;
   }
   
    void print()
  {
  	cout<<"hello"<<endl;
  }
};

// Derived class
class Dog : public Animal {
  public:
    void animalSound(int c) {
    cout << "The dog says: bow wow \n" ;
  }
};

int main() {
  Animal myAnimal;
  Cat myCat;
  Dog myDog;

  myAnimal.animalSound();
  myCat.animalSound();
  myDog.animalSound(5);
  return 0;
}
